{\rtf1\ansi\ansicpg1252\cocoartf1404\cocoasubrtf130
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 READ ME:\
\
My project, as described in the video, is a simulation of an augmented reality. It consists of a Quadcopter controlled by a Raspberry Pi, which is connected to my laptop via a Python library called Sockets. This uses wifi, and the server is hosted on the Raspberry Pi. The project also uses Panda 3D, a 3D game engine, to render the graphics and read user inputs. \
\
The panda3D engine I used can be downloaded here: {\field{\*\fldinst{HYPERLINK "https://www.panda3d.org/download.php?sdk&version=1.9.1"}}{\fldrslt https://www.panda3d.org/download.php?sdk&version=1.9.1}}\
\
Additionally, panda3D uses its own weird modified version of python, so in order to run the script via terminal you\'92d have to type in \'93ppython <filename>.py\'94 instead of the usual python or python3\
\
On the Raspberry Pi, I use the various pin libraries which basically lets me transmit certain data to the Raspberry Pi pins, which are then connected to the motors. \
The Raspberry Pi libraries should come prepackaged with the Raspberry Pi, assuming you\'92ve downloaded the default Linux provided by Raspberry Pi\
\
\
}