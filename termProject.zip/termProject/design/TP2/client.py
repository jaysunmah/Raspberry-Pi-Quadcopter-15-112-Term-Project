
import socket
from _thread import *
import time
import math

# print("type in IP address:")
# HOST = input()
# print("Connecting to", HOST)

HOST = '128.237.238.152'
# HOST = '192.168.1.156'
PORT = 21127

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.connect((HOST, PORT))
print("connected to server")

from tkinter import *

####################################
# customize these functions
####################################

def init(data):
	data.distance = 0
	start_new_thread(handleServerMsg, (server,data))
	data.lock = False
	data.lockDuration = 4
	data.rudX = data.eleX = data.ailX = data.width / 2
	data.rudY = 200
	data.eleY = 300
	data.ailX = 400
	data.ail = 0
	data.ele = 0
	data.thr = 0
	data.rud = 0
	data.gyroX = 0
	data.gyroY = 0


def handleServerMsg(server, data):
	while True:
		listOfMessages = []
		msg = server.recv(1000).decode('UTF-8')
		try:
			msg = eval(msg)
			data.distance = msg["distance"]
			data.gyroX = msg["gyroX"]
			data.gyroY = msg["gyroY"]
			data.ele = msg["ele"]
			data.rud = msg["rud"]
			data.thr = msg["thr"]
			data.ail = msg["ail"]
		except:
			pass

def mousePressed(event, data):
	# use event.x and event.y
	pass

def lockControls(data):
	data.lock = True
	time.sleep(data.lockDuration)
	data.lock = False

def keyPressed(event, data):
	if not data.lock:
		if event.keysym == "Up": server.send(bytes('up', "UTF-8"))
		elif event.keysym == "Down": server.send(bytes('down', "UTF-8"))
		elif event.keysym == "Left": server.send(bytes('left', "UTF-8"))
		elif event.keysym == "Right": server.send(bytes('right', "UTF-8"))
		elif event.keysym == "w": server.send(bytes('w', "UTF-8"))
		elif event.keysym == "s": server.send(bytes('s', "UTF-8"))
		elif event.keysym == "a": server.send(bytes('a', "UTF-8"))
		elif event.keysym == "d": server.send(bytes('d', "UTF-8"))
		elif event.keysym == "p": server.send(bytes('p', "UTF-8"))
		elif event.keysym == "o": server.send(bytes('o', "UTF-8"))
		elif event.keysym == '1':
			start_new_thread(lockControls, (data,))
			server.send(bytes('1', 'UTF-8'))
		elif event.keysym == '2':
			start_new_thread(lockControls, (data,))
			server.send(bytes('2', 'UTF-8'))
		elif event.keysym == '3': server.send(bytes('3', 'UTF-8'))
		elif event.keysym == '4': server.send(bytes('4', 'UTF-8'))

def timerFired(data):
	pass

def roundToHundredth(num):
	num *= 100
	num = round(num)
	num /= 100
	return num

def drawLabels(canvas, data):
	canvas.create_text(150, data.height - 300, 
	text = "THR (up down): " + str(roundToHundredth(data.thr)), anchor = "e")
	canvas.create_text(150, data.height - 200, 
text = "RUD (twist and shout): "+str(roundToHundredth(data.rud)),anchor = "e")
	canvas.create_text(400,data.height - 300, 
text = "ELE (forward backward): " + str(roundToHundredth(data.ele)),anchor="e")
	canvas.create_text(400, data.height - 200, 
text = "AIL (left right): " + str(roundToHundredth(data.ail)), anchor = "e")

def redrawAll(canvas, data):
	if data.lock:
		canvas.create_rectangle(0,0,data.width, data.width, fill = "red")
	canvas.create_text(data.width / 2, 50, text="Distance:"+str(data.distance))
	canvas.create_text(data.width / 2, 150, 
	text = "X:" + str(data.gyroX) + ", Y:" + str(data.gyroY))
	drawLabels(canvas, data)
	canvas.create_line(50,50-math.cos(data.gyroX),100,50+math.cos(data.gyroX))

####################################
# use the run function as-is
####################################

def run(width=300, height=300):
	def redrawAllWrapper(canvas, data):
		canvas.delete(ALL)
		redrawAll(canvas, data)
		canvas.update()    

	def mousePressedWrapper(event, canvas, data):
		mousePressed(event, data)
		redrawAllWrapper(canvas, data)

	def keyPressedWrapper(event, canvas, data):
		keyPressed(event, data)
		redrawAllWrapper(canvas, data)

	def timerFiredWrapper(canvas, data):
		timerFired(data)
		redrawAllWrapper(canvas, data)
		# pause, then call timerFired again
		canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
	# Set up data and call init
	class Struct(object): pass
	data = Struct()
	data.width = width
	data.height = height
	data.timerDelay = 100 # milliseconds
	init(data)
	# create the root and the canvas
	root = Tk()
	canvas = Canvas(root, width=data.width, height=data.height)
	canvas.pack()
	# set up events
	root.bind("<Button-1>", lambda event:
							mousePressedWrapper(event, canvas, data))
	root.bind("<Key>", lambda event:
							keyPressedWrapper(event, canvas, data))
	timerFiredWrapper(canvas, data)
	# and launch the app
	root.mainloop()  # blocks until window is closed
	server.close()
	print("bye!")

run(600, 600)