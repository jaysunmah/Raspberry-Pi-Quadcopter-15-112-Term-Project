from math import pi, sin, cos
import socket
import time
from direct.showbase.ShowBase import ShowBase
from direct.task import Task
from direct.actor.Actor import Actor
from direct.interval.IntervalGlobal import Sequence
from panda3d.core import Point3
import sys
from direct.stdpy import thread
from Queue import Queue
from direct.gui.OnscreenText import OnscreenText
from panda3d.core import TextNode, TransparencyAttrib


####################################
# server setup (sets up the client IP address variables)
####################################

HOST = '128.237.238.152'
PORT = 21127
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.connect((HOST, PORT))
print("connected to server")

####################################
# panda world setup
####################################

class MyApp(ShowBase):
	def __init__(self, server):
		ShowBase.__init__(self)
		#the way the user interface can read held down buttons is by
		#setting the button to be true when it's pressed down, and then
		#it sets it back to false when it's released
		#I have a constant while loop that'll simply read the key dictionary
		#and act whenever one of the values reads True, or in this case 1
		self.keys = {"w": 0, "s": 0, "d": 0, "a":0,"u":0, "e":0,"r": 0,"l": 0}
		#I've tried to use a Queue to send back and forth the registered keys
		#but so far it's not working. Instead, what I'll do for now is to 
		#send two pulses to a server: whenever the button is pressed down
		#and whenever the button is released. On the server end, each pulse 
		#will simply "flip" the value of the key before hand, so it'll go on 
		#and off constantly 
		# self.messageChannel = Queue(100)
		# thread.start_new_thread(self.loadMessageChannel, (server,))
		# thread.start_new_thread(self.sendServerMessage, (server,))
		self.initPart2()

	#part 2 of the init, the first one got taken up by alot of comments

	def initPart2(self):
		#assigns all of the variables needed in the class
		self.defineVariables()

		self.loadEnvironments()
		
		self.loadModels()

		self.camera.setPos(0,0,2)

		self.initializeKeys1()
		self.initializeKeys2()

		
		self.startThreads()

	#these are the data variables that are being sent by the server. so far,
	#I haven't displayed any of these variables, as I've noticed they cause
	#a fair amount of lag/delay, but I am implementing the gyroscope values

	def defineVariables(self):
		self.ail = 0
		self.ele = 0
		self.thr = 0
		self.rud = 0
		self.gyroX = 0
		self.gyroY = 0

		self.cameraSpeed = pi/6
		self.moveSpeed = 0.2

	#loads the environments. So far I have the sky model and a jungle 
	#environment.

	def loadEnvironments(self):
		self.disableMouse()

		self.environ = self.loader.loadModel("models/sky/blue-sky-sphere")
		self.environ.reparentTo(self.render)
		self.environ.setScale(0.25, 0.25, 0.25)
		self.environ.setPos(0, 0, 0)

		self.environ1 = self.loader.loadModel("models/environment")
		self.environ1.reparentTo(self.render)
		self.environ1.setScale(0.25, 0.25, 0.25)
		self.environ1.setPos(0, 0, 0)

	#this method will load all of the models. So far I only have two, but
	#I intend on adding more later

	def loadModels(self):
		self.loadPanda()
		self.loadQuad()


	#this method loads the panda model. It has a walk animation, as well
	#as a movement path

	def loadPanda(self):
		self.pandaActor = Actor("models/panda-model", 
			{"walk": "models/panda-walk4"})
		self.pandaActor.setScale(0.005, 0.005, 0.005)
		self.pandaActor.reparentTo(self.render)
		# Loop its animation.
		self.pandaActor.loop("walk")
		# Create the four lerp intervals needed for the panda to move
		pandaPosInterval1 = self.pandaActor.posInterval(13, Point3(0, -10, 0),
													startPos=Point3(0,10,0))
		pandaPosInterval2 = self.pandaActor.posInterval(13, Point3(0, 10, 0),
													startPos=Point3(0, -10, 0))
		pandaHprInterval1 = self.pandaActor.hprInterval(3, Point3(180, 0, 0),
													startHpr=Point3(0, 0, 0))
		pandaHprInterval2 = self.pandaActor.hprInterval(3, Point3(0, 0, 0),
													startHpr=Point3(180, 0, 0))
		# Create and play the sequence that coordinates the intervals.
		self.pandaPace = Sequence(pandaPosInterval1,pandaHprInterval1, 
			pandaPosInterval2, pandaHprInterval2, name="pandaPace")
		self.pandaPace.loop()

	#this will load the quad model. As of right now, it is only a demo model
	#but I plan on making my own quad model later

	def loadQuad(self):
		# Load and transform the panda actor.
		self.quad = loader.loadModel('models/boeing/boeing707')
		self.quad.reparentTo(self.render)
		self.quad.setScale(0.15, 0.15, 0.15)
		self.quad.setPos(self.camera, 0, 20,-2)

	#sets the keyinputs. I split it into two methods to make it more 
	#readable
	#the way the key inputs are read in panda is pressing the key down
	#generates one pulse, and then releasing the button generates another
	#pulse. Each time a pulse is fired, panda will set the value of a key
	#to be either True (when it's pressed down) or False (when it's not 
	#pressed down). 

	def initializeKeys1(self):
		self.accept("escape", sys.exit)

		self.accept("arrow_up", self.setKey, ["u", 1, server])
		self.accept("arrow_up-up", self.setKey, ["u", 0, server])

		self.accept("arrow_down", self.setKey, ["e", 1, server])
		self.accept("arrow_down-up", self.setKey, ["e", 0, server])

		self.accept("arrow_right", self.setKey, ["r", 1, server])
		self.accept("arrow_right-up", self.setKey, ["r", 0, server])

		self.accept("arrow_left", self.setKey, ["l", 1, server])
		self.accept("arrow_left-up", self.setKey, ["l", 0, server])

	#part two of initialize keys

	def initializeKeys2(self):
		self.accept("w", self.setKey, ["w", 1, server])
		self.accept("w-up", self.setKey, ["w", 0, server])

		self.accept("s", self.setKey, ["s", 1, server])
		self.accept("s-up", self.setKey, ["s", 0, server])

		self.accept("d", self.setKey, ["d", 1, server])
		self.accept("d-up", self.setKey, ["d", 0, server])

		self.accept("a", self.setKey, ["a", 1, server])
		self.accept("a-up", self.setKey, ["a", 0, server])

		self.accept('8', self.sendMsg, ['8', server]) #arm
		self.accept('9', self.sendMsg, ['9', server]) #disarm

	#to make things more organized, I combined all of the threaded methods
	#here, so I can modify/add more in the future if needed

	def startThreads(self):
		thread.start_new_thread(self.rotateQuad, (server,))
		thread.start_new_thread(self.handleServerMsg, (server,))
		thread.start_new_thread(self.moveCamera, (server,))		

	#this method is only used for button actions that don't require buttons
	#to be held down. For example, pressing 8 and 9 will arm and disarm the
	#copter, and holding them down won't do anything. So sendMsg will basically
	#send a single pulse to the server, which will know what to do for 
	#specific single pulses.

	def sendMsg(self, msg, server):
		server.send(bytes(msg))

	#evalKey is only used by the down button. It essentially determines
	#if the copter is on the ground before it tries to lower the quad's
	#actual throttle. I do this to simulate more of a "real" effect, where
	#the quad in real life will only shut down once the quad in the
	#simulation has actually touched the ground.

	def evalKey(self, key, val, server):
		if self.quad.getZ() < 0 and not self.keys['e']:
			self.setKey(key, val, server)
		else:
			self.keys[key] = val

	#set key will merely change the dictionary of keys to whatever value
	#it is inputed. Then, it will send a pulse to the server, which will
	#read it as a double pulse and modify its own variables accordingly. 

	def setKey(self, key, val, server):
		self.keys[key] = val
		server.send(bytes(key))

	def moveCamera(self, server):
		while True:
			#currently the variables are hard to read: 1 stands for the copter
			#being grounded, and 0 stands for it being in the air. 
			#it will send these messages to the server, which will know when to
			#actually give the quad throttle

			if self.quad.getZ() < 0:
				server.send(bytes('1')) #ground
			else:
				server.send(bytes('0')) #air

			if self.keys["w"]:
				self.camera.setPos(self.camera, 0, self.moveSpeed, 0)
				self.quad.setPos(self.camera, 0, 20, -2)

			elif self.keys["s"]:
				self.camera.setPos(self.camera, 0, -self.moveSpeed, 0)
				self.quad.setPos(self.camera, 0, 20, -2)
			self.moveCameraPart2(server)

			if self.keys["d"]:
				# self.camera.setPos(self.camera, self.moveSpeed, 0, 0)
				# self.quad.setPos(self.camera, 0, 20, -2)
				self.quad.setHpr(self.quad, 0, 0, pi / 2)

			elif self.keys["a"]:
				# self.camera.setPos(self.camera, -self.moveSpeed, 0, 0)
				# self.quad.setPos(self.camera, 0, 20, -2)
				self.quad.setHpr(self.quad, 0, 0, -pi / 2)

	def moveCameraPart2(self, server):
		if self.keys["u"]:
			if self.thr >= 6.4:
				self.camera.setPos(self.camera, 0, 0, self.moveSpeed / 2)
				self.quad.setPos(self.camera, 0, 20, -2)
		
		#this is the down arrow, but I had no other key to set it to : /
		#the keys sent must be of one character long because thats how
		#the server can read messages (it goes through each message
		#character by character)

		elif self.keys["e"]: 
			if self.quad.getZ() > -0.01:
				self.camera.setPos(self.camera, 0, 0, -self.moveSpeed / 2)
				self.quad.setPos(self.camera, 0, 20, -2)
				print(self.quad.getZ())

		if self.keys["r"]:
			self.camera.setHpr(self.camera, -self.cameraSpeed, 0, 0)
			self.quad.setHpr(self.camera, 0,0,self.quad.getR())
			print(self.quad.getR())
			self.quad.setPos(self.camera, 0, 20, -2)

		elif self.keys["l"]:
			self.camera.setHpr(self.camera, self.cameraSpeed, 0, 0)
			self.quad.setHpr(self.camera, 0,0,self.quad.getR())
			self.quad.setPos(self.camera, 0, 20, -2)
		time.sleep(0.01)

	#currently working on this aspect of the simulation: the quad is noted
	#to have random bursts of movement which causes a lot of jitter; trying
	#to see how I can manage to stabilize the motion

	def rotateQuad(self, server):
		while True:
			print('gyro', self.gyroX, 'teapot', self.quad.getR())
			error = self.gyroX - self.quad.getR()
			self.quad.setHpr(self.quad, 0, 0, error * 0.05)
			sign = 1
			if self.quad.getR() < 0:
				sign = -1
			self.camera.setPos(self.camera, 
				((self.quad.getR() / 30) ** 4) / 5 * sign, 0, 0)
			self.quad.setPos(self.camera, 0,20,-2)
			time.sleep(0.01)

	def handleServerMsg(self, server):
		while True:
			msg = server.recv(1000).decode('UTF-8')
			try:
				msg = eval(msg)
				self.distance = msg["distance"]
				self.gyroX = msg["gyroX"]
				self.gyroY = msg["gyroY"]
				self.ele = msg["ele"]
				self.rud = msg["rud"]
				self.thr = msg["thr"]
				self.ail = msg["ail"]
			except:
				pass

	# def loadMessageChannel(self, server):
	# 	while True:
	# 		# print(self.keys)
	# 		self.messageChannel.put(repr(self.keys))

	# def sendServerMessage(self, server):
	# 	while True:
	# 		msg = self.messageChannel.get(True, None)
	# 		print(msg)
	# 		server.send(bytes(msg))
 
app = MyApp(server)
app.run()