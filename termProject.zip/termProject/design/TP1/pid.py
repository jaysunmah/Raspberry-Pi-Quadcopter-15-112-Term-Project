import time

prevError = 0
integral = 0
Kp = 0.2
Ki = 0.00001
Kd = 0.00001
desiredVal = 1.234152
actualVal = -40
deltaT = 0.1

#this is more test code that I've been playing around
#with. PID stands for Proportion Integral Derivative
#which is the most commonly used stabilization algorithm
#to stabilize quadcopter motions.

while True:
	error = desiredVal - actualVal
	integral = integral + (error * deltaT)
	derivative = (error - prevError) / deltaT
	actualVal += Kp * error + Ki * integral + Kd * derivative
	print(actualVal)
	prevError = error
	time.sleep(deltaT)


def getChange(desiredVal, actualVal, prevError = 0, 
	Kp = 0.2, Ki = 0.00001, Kd = 0.00001, deltaT = 0.1):
	error = desiredVal - actualVal
	integral = integral + (error * deltaT)
	derivative = (error - prevError) / deltaT
	return Kp * error + Ki * integral + Kd * derivative


def selfLevel():
	#accVals
	#desiredVal ~ 0,0

